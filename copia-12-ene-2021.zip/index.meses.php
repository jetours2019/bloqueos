<?
#asignamos el nombre del mes de regreso
    switch ($mes) {
       case 1:
             $mes2="Enero";
             break;
       case 2:
             $mes2="Febrero";
             break;
       case 3:
             $mes2="Marzo";
             break;
       case 4:
             $mes2="Abril";
             break;      
       case 5:
             $mes2="Mayo";
             break; 
       case 6:
             $mes2="Junio";
             break;       
       case 7:
             $mes2="Julio";
             break;       
        case 8:
             $mes2="Agosto";
             break;      
        case 9:
             $mes2="Septiembre";
             break;      
        case 10:
             $mes2="Octubre";
             break;      
        case 11:
             $mes2="Noviembre";
             break; 
        case 12:
             $mes2="Diciembre";
             break;      
    }